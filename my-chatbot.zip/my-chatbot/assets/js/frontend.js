
// When ready :)
jQuery(document).ready(function() {

	/*
	 * When the user enters text in the text input text field and then the presses Enter key
	 */
	jQuery("input.myc-text").keypress(function(event) {
		if (event.which == 13) {
			event.preventDefault();
			jQuery(".myc-conversation-area .myc-conversation-request").removeClass("myc-is-active");

			var text = jQuery(this).val();
			var date = new Date();

			var containerId = jQuery(this).closest(".myc-container").attr('id');
			var parts = containerId.split("-");
			var sequence = parts[2];

			var innerHTML = "<div class=\"myc-conversation-bubble-container myc-conversation-bubble-container-request\" style=\"padding:1px 1px 1px 1px;margin-right: -10px;\"><div class=\"myc-conversation-bubble myc-conversation-request myc-is-active\">" + escapeTextInput(text) + "</div>";
			if (myc_script_vars.show_time) {
				innerHTML += "<div class=\"myc-datetime\">" + date.toLocaleTimeString(navigator.language, {hour: '2-digit', minute:'2-digit'}) + "</div>";
			}
			innerHTML += "</div>";
			if (myc_script_vars.show_loading) {
				innerHTML += "<div class=\"myc-loading\"><i class=\"myc-icon-loading-dot\" /><i class=\"myc-icon-loading-dot\" /><i class=\"myc-icon-loading-dot\" /></div>";
			}
			jQuery("#myc-container-" + sequence + " .myc-conversation-area").append(innerHTML);
			jQuery("#myc-container-" + sequence + " input.myc-text").val("");
			jQuery("#myc-container-" + sequence + " .myc-conversation-area")
					.scrollTop(jQuery("#myc-container-" + sequence + " .myc-conversation-area")
					.prop("scrollHeight"));
			textQuery(text, sequence);
		}
	});

	/*
	 * Welcome
	 */
	if (myc_script_vars.enable_welcome_event) {

		// show welcome intent on first chatbot only
		if ( jQuery(".myc-container").length > 0 ) {

			// check if toggled...
			jQuery(".myc-container").each( function( index, value ) {

				// Do not show welcome intent if overlay has not been opened yet
				if (jQuery(this).closest(".myc-content-overlay").length > 0) {
					if (jQuery(this).closest(".myc-content-overlay").hasClass("myc-toggle-closed")) {
						return true; // skip, same as continue
					}
				}

				var containerId = jQuery(this).attr('id');
				var parts = containerId.split("-");
				var sequence = parts[2];

				welcomeIntent(sequence);

			});

		}
	}


	/* Overlay slide toggle */
	jQuery(".myc-content-overlay .myc-content-overlay-header").click(function(event){

		if (jQuery(this).find(".myc-icon-toggle-up").css("display") !== "none") { // toggle open

			var container = jQuery(this).siblings(".myc-content-overlay-container").find(".myc-container");

			// if welcome intent enabled and no conversation exists yet
			if (myc_script_vars.enable_welcome_event && jQuery(container).find(".myc-conversation-bubble-container").length == 0) {

				var containerId = jQuery(container).attr('id');
				var parts = containerId.split("-");
				var sequence = parts[2];

				welcomeIntent(sequence);
			}

			jQuery(this).find(".myc-icon-toggle-up").hide();
			jQuery(this).parent().removeClass("myc-toggle-closed");
			jQuery(this).parent().addClass("myc-toggle-open");
			jQuery(this).find(".myc-icon-toggle-down").show();
			jQuery(this).siblings(".myc-content-overlay-container, .myc-content-overlay-powered-by").slideToggle("slow",function() {});
		} else { // toggle close
			jQuery(this).find(".myc-icon-toggle-down").hide();
			jQuery(this).parent().removeClass("myc-toggle-open");
			jQuery(this).parent().addClass("myc-toggle-closed");
			jQuery(this).find(".myc-icon-toggle-up").show();
			jQuery(this).siblings(".myc-content-overlay-container, .myc-content-overlay-powered-by").slideToggle("slow",function() {});
		}
	});

});


/**
 * Displays welcome intent for a specific chatbot identified by sequence
 *
 * @params sequence
 */
function welcomeIntent(sequence) {

	jQuery.ajax({
		type : "POST",
		url : myc_script_vars.base_url + "query?v=" + myc_script_vars.version_date,
		contentType : "application/json; charset=utf-8",
		dataType : "json",
		headers : {
			"Authorization" : "Bearer " + myc_script_vars.access_token
		},
		data : JSON.stringify( {
			event : {
				name : "WELCOME"
			},
			lang : myc_script_vars.language,
			sessionId : myc_script_vars.session_id,
		} ),
		success : function(response) {
			prepareResponse(response, sequence);
		},
		error : function(response) {
			textResponse(myc_script_vars.messages.internal_error, sequence);
			jQuery("#myc-container-" + sequence + " .myc-conversation-area")
					.scrollTop(jQuery("#myc-container-" + sequence + " .myc-conversation-area")
					.prop("scrollHeight"));
		}
	});

}

/**
 * Send Dialogflow query
 *
 * @param text
 * @param sequence
 * @returns
 */
function textQuery(text, sequence) {

	jQuery.ajax({
		type : "POST",
		url : myc_script_vars.base_url + "query?v=" + myc_script_vars.version_date,
		contentType : "application/json; charset=utf-8",
		dataType : "json",
		headers : {
			"Authorization" : "Bearer " + myc_script_vars.access_token
		},
		data: JSON.stringify( {
			query: text,
			lang : myc_script_vars.language,
			sessionId: myc_script_vars.session_id
		} ),
		success : function(response) {
			setTimeout(function(){
				if (myc_script_vars.show_loading) {
					jQuery("#myc-container-" + sequence + " .myc-loading").empty();
				}
				prepareResponse(response,sequence);
			}, myc_script_vars.response_delay);

		},
		error : function(response) {
			if (myc_script_vars.show_loading) {
				jQuery("#myc-container-" + sequence + " .myc-loading").empty();
			}
			textResponse(myc_script_vars.messages.internal_error, sequence);
			jQuery("#myc-container-" + sequence + " .myc-conversation-area")
					.scrollTop(jQuery(".myc-container-" + sequence + " .myc-conversation-area")
					.prop("scrollHeight"));
		}
	});
}

/**
 * Handle Dialogflow response
 *
 * @param response
 * @param response
 */
function prepareResponse(response, sequence) {

	if (response.status.code == "200" ) {

		jQuery(window).trigger("myc_response_success", response);

		jQuery("#myc-container-" + sequence + " .myc-conversation-area .myc-conversation-response").removeClass("myc-is-active");

		var messages = response.result.fulfillment.messages;
		var numMessages = messages.length;
		var index = 0;
		for (index; index<numMessages; index++) {
			var message = messages[index];

			if (myc_script_vars.messaging_platform == message.platform
					|| myc_script_vars.messaging_platform == "default" && message.platform === undefined
					|| message.platform === undefined && ! hasPlatform(messages, myc_script_vars.messaging_platform) ) {

				switch (message.type) {
				    case 0: // text response
						textResponse(message.speech, sequence);
				        break;
				    case 1: // TODO card response
				        cardResponse(message.title, message.subtitle, message.buttons, message.text, message.postback, sequence);
				        break;
				    case 2: // quick replies
				    	quickRepliesResponse(message.title, message.replies, sequence);
				        break;
				    case 3: // image response
						imageResponse(message.imageUrl, sequence);
				        break;
				    case 3: // custom payload

				        break;
				    default:
				}
			}
		}

	} else {
		textResponse(myc_script_vars.messages.internal_error, sequence);
	}

	jQuery("#myc-container-" + sequence + " .myc-conversation-area")
			.scrollTop(jQuery("#myc-container-" + sequence + " .myc-conversation-area")
			.prop("scrollHeight"));

	if (jQuery("#myc-container-" + sequence + " #myc-debug-data").length) {
		var debugData = JSON.stringify(response, undefined, 2);
		jQuery("#myc-container-" + sequence + " #myc-debug-data").text(debugData);
	}
}

/**
 * Checks if messages support a specific platform
 *
 * @param messages
 * @param platform
 * @returns {Boolean}
 */
function hasPlatform(messages, platform) {
	var numMessages = messages.length;
	var index = 0;
	for (index; index<numMessages; index++) {
		var message = messages[index];
		if (message.platform === platform) {
			return true;
		}
	}

	return false;
}

/**
 * Displays a text response
 *
 * @param text
 * @param sequence
 * @returns
 */
function textResponse(text, sequence) {
	if (text === "") {
		text = myc_script_vars.messages.internal_error;
	}
	var date = new Date();
	var innerHTML = "<span class=\"response-img\" style=\"display:inline-block;width:20px;float:left;margin-left:-12px; vertical-align:middle;\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHkAAAB5CAMAAAAqJH57AAAAMFBMVEXBx9D///++xM7W2uDIzdXa3ePq7O/3+Pn7+/zN0dnf4ubFytPk5urn6e3z9PbS1t1bZn1JAAAE2UlEQVRogcWb25KlIAxFI6J49///thFtLxBgg1hnv0zVtIdlIgQIgapkqXYe6rWXIxGNsl/rYW5VejOUCG16YUSX9v/om0R8AnlpJD2QT+k/yWYpT9bYAPWi43CI3E09gP2H91NXiNw1I4o94GMDsKPkroHNvRseZ8fIOdyD/Yo8UR7XsGnKJiuZzzVsGRrhAfLwjmvYQwZZ9e/BGt17zfaR2xdf+IGmNo3clOEatqeT8+Qinj7RPUzuXvZpBy25sMKQ3w4mDs30M5e8FAdvaHcGc8jlLd7RjtU2ufQ3vtD2t7bJH4E3dJi8fgXW6DVEhgOIXvJtq069AhX4aqXxk1usEb3gGZb/z9YtA7pUEq2PrLDfU233U1WDUV55yFDMFA53Z0O/vcfRGxmZj8Xom3raEUHf5uuLvCBgPvgbdYjLxBXLLnIP/K72g7UQj1+vfpInYAcRBkNocS4LT3L8dSngatxvF/D4F4khUTDy/mc8OZrrAD/5evVdQCwS3YMcN9kOux7FA/+/0QSbjO3LFWw0lTU5wWhD7qLvSYRuyIGANHYnGRjL9rzul4y2tY9pQ44Pw+ie9BIwPvt/MuAgaEjtQgbWcpCRKIJnnIBZ3niQoC9D7C6BV4c0t5OR6RHvYJAhm7sJc3Z8sriETLeNIQPvWJq8+ZCwdV9psu6xhC11S5P1KCVsdV+4b28fmqDPjIdtPVSg9qQmQ2v0sjFsa7AiYEIlYPF3CVrz6+mewL1UybnKkFuac3Zjr51NYiY0x4iOK2g0b/scqrEn7/uSkJBJwKimFXwSNBo0mTQXflTMABjsNZshhHVFg47HMWD1/C9JyLb30BglpzSGPxrePe8f+bPMklhDDoe27tloJn/5r+R8aZK/SZCvh89pWM3F+/bBZs1OTxBLfDxf7N6O4W3GF+7xGHZnUz0fScBumdesw5YVjtsWW2zn7XI7d8/s0DU8VxWWnqvwSFuWPKNrkuLkFlyHlScrcO1Zngyvt0tLonuM0jJ7DKSLiTQBDbbAXlKMsq/T1MtofFHR/bOQc0JdzCk1h6cQGcsZCInvp2y1AfaRM/AvkUNlAoD8gfnIk3jdnbCB9JjtQx+5IZ+7X4O96DMfxrv7pat38Q4/c4D8liQlNeKXv2lvrhfcwcXE+fOW6+Xy22VM5o2+8ttMHyvQvXa5neye0+d2YhnVjKzc4Pw4x3CNLuVs193PsxvXaPTAJC57WW2dV9lGJ2ShYrKyVPYZnX2u9x3ZOZe0xvRnZOYs9tkTPiMz58/PaPMVmT1zf0T3j8h8ncEjzfEN2Vdb8Qg3Can0iO7j2VdPco+xfB1bhm6Bwl9D83ysDPru60DdkJXRej9D36vN7GxaqD7s9XpoobsPrT8Ga+Lgg3Zej2EarYl71gGKMd/jan2Ao3WAdmoLKAHn9SjAhmof7epHMSJ5bVvW62P1nk79YyjZyUutVgNgjWvllGa4Wb+QFvvXfD8Fa5nFiF11YDKRabXMTP22oDVu+NK4P0us3+Zq1oUY68DdGtU2bqogo2a9YndjGi7rdlGW55Vqazly+ZGcOv3KV1y8ZWDM3aZhmqZhv+/EZ2Wy7yZUwfsY0UTQm/sYm351B6X64b2b6nd3jQz7R/erjH50p+yE/+Ie3a4f3R288EXuS/4BrV8vypyyNVYAAAAASUVORK5CYII=\" width=\"15px\" height=\"5px\"></span><div class=\"myc-conversation-bubble-container myc-conversation-bubble-container-response\"><div class=\"myc-conversation-bubble myc-conversation-response myc-is-active myc-text-response\">" + text + "</div>";
	if (myc_script_vars.show_time) {
		innerHTML += "<div class=\"myc-datetime\" style=\"margin-left:14px\">" + date.toLocaleTimeString(navigator.language, {hour: '2-digit', minute:'2-digit'}) + "</div>";
	}
	innerHTML += "</div>";
	jQuery("#myc-container-" + sequence + " .myc-conversation-area").append(innerHTML);
}

/**
 * Displays a image response
 *
 * @param imageUrl
 * @param sequence
 * @returns
 */
function imageResponse(imageUrl, sequence) {
	if (imageUrl === "") {
		textResponse(myc_script_vars.messages.internal_error, sequence)
	} else {
		// FIXME wait for image to load by creating HTML first
		var date = new Date();
		var innerHTML = "<div class=\"myc-conversation-bubble-container myc-conversation-bubble-container-response \"><div class=\"myc-conversation-bubble myc-conversation-response myc-is-active myc-image-response\"><img src=\"" + imageUrl + "\"/></div>";
		if (myc_script_vars.show_time) {
			innerHTML += "<div class=\"myc-datetime\">" + date.toLocaleTimeString(navigator.language, {hour: '2-digit', minute:'2-digit'}) + "</div>";
		}
		innerHTML += "</div>";
		jQuery("#myc-container-" + sequence + " .myc-conversation-area").append(innerHTML);
	}
}

/**
 * Card response
 *
 * @param title
 * @param subtitle
 * @param buttons
 * @param text
 * @param postback
 * @param sequence
 */
function cardResponse(title, subtitle, buttons, text, postback, sequence) {
	var html = "<div class=\"myc-card-title\">" + title + "</div>";
	html += "<div class=\"myc-card-subtitle\">" + subtitle + "</div>";
	// TODO
}

/**
 * Quick replies response
 *
 * @param title
 * @param replies
 * @param sequence
 */
function quickRepliesResponse(title, replies, sequence) {

	var html = "<div class=\"myc-quick-replies-title\">" + title + "</div>";

	var index = 0;
	for (index; index<replies.length; index++) {
		html += "<input type=\"button\" class=\"myc-quick-reply\" value=\"" + replies[index] + "\" />";
	}

	var date = new Date();
	var innerHTML = "<div class=\"myc-conversation-bubble-container myc-conversation-bubble-container-response\"><div class=\"myc-conversation-bubble myc-conversation-response myc-is-active myc-quick-replies-response\">" + html + "</div>";
	if (myc_script_vars.show_time) {
		innerHTML += "<div class=\"myc-datetime\">" + date.toLocaleTimeString(navigator.language, {hour: '2-digit', minute:'2-digit'}) + "</div>";
	}
	innerHTML += "</div>";
	jQuery("#myc-container-" + sequence + " .myc-conversation-area").append(innerHTML);

	jQuery("#myc-container-" + sequence + " .myc-conversation-area .myc-is-active .myc-quick-reply").click(function(event) {
		event.preventDefault();
		jQuery("#myc-container-" + sequence + " .myc-conversation-area .myc-conversation-request").removeClass("myc-is-active");
		var text = jQuery(this).val()
		var date = new Date();
		var innerHTML = "<div class=\"myc-conversation-bubble-container myc-conversation-bubble-container-request\"><div class=\"myc-conversation-bubble myc-conversation-request myc-is-active\">" + escapeTextInput(text) + "</div>";
		if (myc_script_vars.show_time) {
			innerHTML += "<div class=\"myc-datetime\">" + date.toLocaleTimeString(navigator.language, {hour: '2-digit', minute:'2-digit'}) + "</div>";
		}
		if (myc_script_vars.show_loading) {
			innerHTML += "<div class=\"myc-loading\"><i class=\"myc-icon-loading-dot\" /><i class=\"myc-icon-loading-dot\" /><i class=\"myc-icon-loading-dot\" /></div>";
		}
		innerHTML += "</div>";
		jQuery("#myc-container-" + sequence + " .myc-conversation-area").append(innerHTML);
		textQuery(text, sequence);
	});

}

/**
 * Custom payload
 *
 * @param payload
 */
function customPayload(payload, sequence) {

}


var entityMap = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
  '/': '&#x2F;',
  '`': '&#x60;',
  '=': '&#x3D;'
};

/**
 * Escapes HTML in text input
 */
function escapeTextInput(text) {
  return String(text).replace(/[&<>"'`=\/]/g, function (s) {
    return entityMap[s];
  });
}
