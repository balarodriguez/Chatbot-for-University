<!--<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">-->
<div id="myc-container-<?php echo $sequence; ?>" class="myc-container">

	<?php do_action( 'myc_shortcode_before_conversation_area' ); ?>

	<div class="myc-conversation-area"></div>
	<div id="myc-input-area" style="border-top:1px solid #808080;">
		<input class="myc-text" style="outline:none;border:1px;box-shadow:none;" type="text" placeholder="<?php echo $input_text; ?>">
	</div>

</div>

<?php if ( $debug ) { ?>
	<div class="myc-debug">
		<textarea id="myc-debug-data" style="outline:none;border:1px;box-shadow:none;" cols="80" rows="20" disabled></textarea>
	</div>
<?php } ?>
