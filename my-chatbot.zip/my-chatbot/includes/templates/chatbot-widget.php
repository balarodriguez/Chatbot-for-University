<?php
if ( ! empty( $title ) ) {
	echo "$before_title" . esc_html( $title ) . "$after_title";
}
?>


<div id="myc-container-<?php echo $sequence; ?>" class="myc-container">

	<?php do_action( 'myc_widget_before_conversation_area' ); ?>

	<div class="myc-conversation-area"></div>
	<div id="myc-input-area" style="border-top:1px solid silver;">
		<input class="myc-text" type="text" style="outline:none;border:none;box-shadow:none;" placeholder="<?php echo $input_text; ?>">
		
	</div>
</div>



<?php if ( $debug ) { ?>
	<div class="myc-debug">
		<textarea id="myc-debug-data" style="outline:none;border:1px;box-shadow:none;" cols="90" rows="15" disabled></textarea>
	</div>
<?php } ?>
